# PMD JSP

Contains the PMD implementation to support Java Server Pages.

For the available rules, see <a href="rules/index.html">rulesets index</a> page.
