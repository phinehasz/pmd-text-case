/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */
package net.sourceforge.pmd.lang.java.rule.unusedcode.unusedprivatemethod;

/**
 * Sample class
 */
public class DashboardGraphInnateFilter_o extends DashboardInnateFilter_o {
    // yes, this is empty, it just need to be a subclass.
}
