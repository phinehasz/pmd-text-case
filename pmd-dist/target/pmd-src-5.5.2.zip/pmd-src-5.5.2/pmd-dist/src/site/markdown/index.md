# PMD Distribution Packages

This is the maven module, which generates the binary and source packages of PMD.
